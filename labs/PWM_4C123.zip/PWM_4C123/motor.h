void motor_PWM_Init(uint16_t period, uint16_t duty);


void motor_Set_Duty(uint16_t duty);

void motor_Off();