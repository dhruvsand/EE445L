
void Tach_Init(void);

uint32_t Tach_GetPeriod(void);

uint32_t Tach_GetFreq(void);

uint32_t Tach_GetSpeed(void);