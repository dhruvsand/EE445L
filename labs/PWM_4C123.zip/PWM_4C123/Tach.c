#include <stdint.h>

void Tach_Init(void){


}

uint32_t Tach_GetPeriod(void){

return 1;
}

uint32_t Tach_GetFreq(void){

return 1;
}

uint32_t Tach_GetSpeed(void){


return 1;
}