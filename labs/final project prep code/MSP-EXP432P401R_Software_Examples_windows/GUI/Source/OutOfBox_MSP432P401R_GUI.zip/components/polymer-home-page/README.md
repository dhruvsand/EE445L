polymer-home-page
=================

Component which renders a Polymer-standard element landing page (vulcanized with polymer.html included).
