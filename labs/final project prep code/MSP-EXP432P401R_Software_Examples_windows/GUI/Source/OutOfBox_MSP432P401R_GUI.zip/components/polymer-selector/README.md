polymer-selector
================

[LICENSE](https://raw.github.com/Polymer/polymer/master/LICENSE)

[PATENTS](https://raw.github.com/Polymer/polymer/master/PATENTS)

[CONTRIBUTING](https://github.com/Polymer/polymer/blob/master/CONTRIBUTING.md)
