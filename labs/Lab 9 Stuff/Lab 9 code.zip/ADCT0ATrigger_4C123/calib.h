#include <stdint.h>

int32_t Temperature_Convert(int32_t);
